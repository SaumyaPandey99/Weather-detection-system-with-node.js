const submitBtn = document.getElementById('submitBtn');
const cityname = document.getElementById('cityname'); // Removed extra space
const city_name = document.getElementById('city_name');

const getInfo = async (event) => {
    event.preventDefault(); // Prevent form from submitting

    let cityVal = cityname.value; // Use .value to get input value

    if (cityVal === "") {
        city_name.innerText = `Please write the city name before searching.`;
    } else {
        try {
            let url = `http://api.openweathermap.org/data/2.5/weather?q=${cityVal}&units=metric&appid=1e08d9f81cac36e88f27ecdc11a07329`;
            const response = await fetch(url);
            const data = await response.json();
            city_name.innerText = `Weather info for ${cityVal}: ${data.weather[0].description}, ${data.main.temp}°C`; // Example of displaying data
        } catch (error) {
            city_name.innerText = `Please enter the city name properly.`;
            console.error(error); // Logs the error
        }
    }
};

submitBtn.addEventListener('click', getInfo);

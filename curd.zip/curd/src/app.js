/*const express = require('express');
const path = require('path');
const hbs = require('hbs')
const app = express();
const port = process.env.PORT || 3000;
const static_path = path.join(__dirname, "../public"); 
const template_path = path.join(__dirname, "../templates/views"); 
const partials_path = path.join(__dirname, "../templates/partials"); 


app.set('view engine', 'hbs');
app.set('views',template_path);
hbs.registerPartials(partials_path);
app.use(express.static(static_path));
app.get('/index', (req, res) => {
  res.render('index');
});
app.get('/about', (req, res) => {
  res.render('about');
});
app.get('/Weather', (req, res) => {
  res.send('Welcome to Saumya Website3');
});
app.get('*', (req, res) => {
  res.render('404');  
});
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});*/

const express = require('express');
const path = require('path');
const hbs = require('hbs');
const app = express();
const port = process.env.PORT || 3000;

// Paths to the directories
const static_path = path.join(__dirname, "../public");  // Public directory for static files
const template_path = path.join(__dirname, "../templates/views");  // Path to views
const partials_path = path.join(__dirname, "../templates/partials");  // Path to partials

// Setup handlebars engine and views location
app.set('view engine', 'hbs');
app.set('views', template_path);
hbs.registerPartials(partials_path);

// Static files middleware
app.use(express.static(static_path));

// Routes
app.get('/', (req, res) => {
  res.render('index');  // Renders index.hbs from views
});

app.get('/about', (req, res) => {
  res.render('about');  // Renders about.hbs from views
});

app.get('/weather', (req, res) => {
  res.render('weather');  // Simple response for weather route
});


app.get('*', (req, res) => {
  res.render('404', {
    errorMsg: 'Oops! Page not found'  // Passes errorMsg to the 404 view
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
